#include"filesplitter.h"
#include<iostream>
#include<string.h>
using namespace std;

class SecureShare
{
	filesplitter s;
	
 public: void Callsplitter(char file[20])
	 { 
                char loc[30];
                strcpy(loc,"/home/madhura/Desktop/");
		s.getFileInfo(file,loc);
                s.split();
                s.sendParts();
	 }

	 /*void Callmerger(char file1[20],char file2[20])
	 {
		
	 }*/
};

int main(int argc,char *argv[])
{
	SecureShare s;
	
	if(argc==2)
	{
		s.Callsplitter(argv[1]);
	}
	
	if(argc==3)
	{
		//cout<<argv[1]<<argv[2];
		//s.Callmerger(argv[1],argv[2]);	
	}
	
	return 0;
}
