#include<iostream>
#include"filesplitter.h"
#include"FactoryWrite.h"
#include<fstream>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
using namespace std;

void filesplitter::getFileInfo(char name[40],char loc[40])
{
strcpy(fileName,name);
strcpy(fileLocation,loc);
}
int filesplitter::fileopen(char file[60],fstream* f1)
{

       int end;
	f1->open(file,ios::in|ios::binary|ios::ate);
	end = f1->tellg();
	f1->seekg(0,ios::beg);
	if(!(*f1))
	{
		cout<<"could not open file";
		exit(0);
	}
	return end;
}
void filesplitter::fileread(char buff[20],fstream* f1)
{
   f1->read(buff,1);
}
int filesplitter::fileclose(fstream* f1)
{
   f1->close();
   return(0);
}
void filesplitter::split()
{
 char buff,part1[40],part2[40],part3[40],file[60],header1[80],header2[80],header3[80];
 fstream f1,f2,f3,f4;
 int i,fx[3],temp,buff1,end,res;
strcpy(file,fileLocation);
strcat(file,fileName);	
end = fileopen(file,&f1);
fileSize=end;
cout<<"\n file:"<<fileLocation;
strcpy(header1,"Cloud path:madhura/cloud/");
strcat(header1,fileName);
strcat(header1,"\n");
strcat(header1,"Usb path:madhura/usb/");		
strcat(header1,fileName);
strcat(header1,"\n");	
strcat(header1,"2\n");	

strcpy(header2,"Local path:local/");
strcat(header2,fileName);
strcat(header2,"\n");
strcat(header2,"Usb path:madhura/usb/");		
strcat(header2,fileName);
strcat(header2,"\n");	
strcat(header2,"4\n");	


strcpy(header3,"Cloud path:madhura/cloud/");
strcat(header3,fileName);
strcat(header3,"\n");
strcat(header3,"local/");		
strcat(header3,fileName);
strcat(header3,"\n");	
strcat(header3,"3\n");	

	strcpy(part1,fileLocation);
	strcpy(part2,fileLocation);
	strcpy(part3,fileLocation);

	strcat(part1,"1");	
	strcat(part2,"2");	
	strcat(part3,"3");	

	strcat(part1,fileName);	
	strcat(part2,fileName);	
	strcat(part3,fileName);

	f2.open(part1,ios::out|ios::binary);
	f3.open(part2,ios::out|ios::binary);
	f4.open(part3,ios::out|ios::binary);
        
	
		if(!f2 || !f3 || !f4)
		{			
			cout<<"could not open";
			exit(0);
		}
        
        f2<<"FileSize:"<<fileSize<<"\n";
	f2<<header1;
        f3<<"FileSize:"<<fileSize<<"\n";
        f3<<header2;
        f4<<"FileSize:"<<fileSize<<"\n";	
        f4<<header3;		
	/*temp = 2;
	buff = temp;
	f2.write(&buff,1);
	
	temp = 4;
	buff = temp;
	f3.write(&buff,1);

	temp = 3;
	buff = temp;
	f4.write(&buff,1);*/

	while(end > 0)
	{
		fileread(&buff,&f1);		
		buff1 = buff;	
		//cout<<buff1<<endl;

		i=0;	
		fx[i++] = (50*2)+buff1;
		fx[i++] = (50*4)+buff1;							
		fx[i++] = (50*3)+buff1;
	
		i=0;
		buff = fx[i++];
		f2.write(&buff,1);
		//cout<<fx[i]<<endl;
		buff = fx[i++];
		f3.write(&buff,1);
		buff = fx[i++];
		f4.write(&buff,1);
		end--;				
	}
	
res=fileclose(&f1);
res=fileclose(&f2);
res=fileclose(&f3);
res=fileclose(&f4);
}
void filesplitter::sendParts()
{
 IWrite *write;
 FactoryWrite factory;
 fstream fout;
 int i=0,j=0,k=0;
 char part1[40],part2[40],part3[40],temp[100];
 char localpath[80],cloudpath[80],usbpath[80],templocalpath[80],tempcloudpath[80],tempusbpath[80];
 fstream f1,f2,f3;
        strcpy(part1,fileLocation);
	strcpy(part2,fileLocation);
	strcpy(part3,fileLocation);

	strcat(part1,"1");	
	strcat(part2,"2");	
	strcat(part3,"3");	

	strcat(part1,fileName);	
	strcat(part2,fileName);	
	strcat(part3,fileName);
cout<<"\n"<<part1;
fileopen(part1,&f1);
fileopen(part2,&f2);
 f1.getline(temp,80);
 f1.getline(tempcloudpath,80);
 f1.getline(tempusbpath,80);
 fileclose(&f1);  
 f2.getline(temp,80);
strcpy(templocalpath,fileLocation);
 f2.getline(temp,80);
//strcat(templocalpath,temp);

 fileclose(&f2); 
i=0;
j=0; 
k=0;
while(temp[i]!='\0')
{
     while(1)
     {
         if(temp[k]==':')
         break;
         k++;
         i=k;
      }
     
    localpath[j++]=temp[++i];
}
strcat(templocalpath,localpath);
strcpy(localpath,templocalpath);
cout<<"\ntt"<<templocalpath;
i=0;
j=0; 
k=0;
while(tempcloudpath[i]!='\0')
{
     while(1)
     {
         if(tempcloudpath[k]==':')
         break;
         k++;
         i=k;
      }
     
    cloudpath[j++]=tempcloudpath[++i];
}
cloudpath[i]='\0';
i=0;
j=0; 
k=0;
while(tempusbpath[i]!='\0')
{
     while(1)
     {
         if(tempusbpath[k]==':')
         break;
         k++;
         i=k;
      }
     
    usbpath[j++]=tempusbpath[++i];
}
usbpath[i]='\0';
cout<<"\nLocal"<<localpath;
cout<<"\ncloud"<<cloudpath;
cout<<"\nUsb"<<usbpath; 
write=factory.createInstance(localpath);
write->getfilename(part1);
write->filewrite(localpath,&fout);          
}
