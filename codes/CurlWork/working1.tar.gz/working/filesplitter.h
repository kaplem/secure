//#include<iostream>
#include"Iread.h"
#include<fstream>
//using namespace std;
class filesplitter:public IRead
{
char fileName[40];
char fileLocation[40];
int fileSize;
public:
int fileopen(char a[60],fstream*);
void fileread(char[],fstream*);
int fileclose(fstream*);
void getFileInfo(char[],char[]);
void split();
void sendParts();
};
