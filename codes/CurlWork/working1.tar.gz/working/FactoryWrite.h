#include"Iwrite.h"
class FactoryWrite
{
public:
IWrite* createInstance(char*);
//char *getString(char*);
int check(char*);
};
