#include<iostream>
#include<fstream>
using namespace std;
class IWrite
{
public:
virtual int fileopen(char[],fstream*)=0;
virtual void filewrite(char[],fstream*)=0;
virtual int fileclose(fstream*)=0;
virtual void getfilename(char [])=0;
};
